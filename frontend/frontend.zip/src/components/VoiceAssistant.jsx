import React, { useState, useEffect, useRef } from 'react';
import { FaMicrophone, FaMicrophoneSlash, FaTimes, FaRobot, FaPaperPlane, FaVolumeUp } from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

/**
 * ChatGPT-Style Voice Assistant
 * Features:
 * - Conversational AI (ask questions, get immediate answers)
 * - Voice input and text-to-speech output
 * - Chat history
 * - Can also fill trip planning form
 * - Multi-language voice support (Hindi, Spanish, French, etc.)
 */
function VoiceAssistant({ darkMode, onVoiceCommand }) {
  // States
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentTranscript, setCurrentTranscript] = useState('');
  const [textInput, setTextInput] = useState('');
  const [voicesLoaded, setVoicesLoaded] = useState(false);
  const [chatHistory, setChatHistory] = useState([
    {
      role: 'assistant',
      content: "👋 Hi! I'm your AI travel assistant. Ask me anything about travel or say 'plan a trip to Paris' to start planning!",
      timestamp: new Date()
    }
  ]);

  // Refs
  const recognitionRef = useRef(null);
  const synthRef = useRef(window.speechSynthesis);
  const chatEndRef = useRef(null);
  const silenceTimerRef = useRef(null);

  // Check browser support
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setIsSupported(true);
      initializeSpeechRecognition();
    } else {
      setIsSupported(false);
      console.warn('Speech recognition not supported in this browser');
    }

    // Load voices
    loadVoices();
    
    // Some browsers load voices async
    if (synthRef.current) {
      synthRef.current.onvoiceschanged = loadVoices;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  // Load available voices
  const loadVoices = () => {
    const voices = synthRef.current.getVoices();
    console.log('Available voices:', voices.map(v => `${v.name} (${v.lang})`));
    setVoicesLoaded(voices.length > 0);
  };

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // Initialize speech recognition
  const initializeSpeechRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;
    recognitionRef.current.lang = 'en-US';

    recognitionRef.current.onresult = (event) => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setCurrentTranscript(transcript);

      // Auto-send after silence
      clearTimeout(silenceTimerRef.current);
      if (event.results[current].isFinal) {
        silenceTimerRef.current = setTimeout(() => {
          handleSendMessage(transcript);
        }, 1500); // Send after 1.5 seconds of silence
      }
    };

    recognitionRef.current.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
      
      if (event.error === 'not-allowed') {
        toast.error('🎤 Microphone access denied. Please enable it in browser settings.');
      } else if (event.error === 'no-speech') {
        // Silent error - user will try again
      } else if (event.error === 'network') {
        toast.error('❌ Network error. Please check your connection.');
      }
    };

    recognitionRef.current.onend = () => {
      setIsListening(false);
      setCurrentTranscript('');
    };
  };

  // Detect language from text
  const detectLanguage = (text) => {
    // Simple language detection based on Unicode ranges
    const hindiRegex = /[\u0900-\u097F]/;
    const arabicRegex = /[\u0600-\u06FF]/;
    const chineseRegex = /[\u4E00-\u9FFF]/;
    const japaneseRegex = /[\u3040-\u309F\u30A0-\u30FF]/;
    const koreanRegex = /[\uAC00-\uD7AF]/;
    const russianRegex = /[\u0400-\u04FF]/;
    
    if (hindiRegex.test(text)) return 'hi-IN';
    if (arabicRegex.test(text)) return 'ar-SA';
    if (chineseRegex.test(text)) return 'zh-CN';
    if (japaneseRegex.test(text)) return 'ja-JP';
    if (koreanRegex.test(text)) return 'ko-KR';
    if (russianRegex.test(text)) return 'ru-RU';
    
    // Check for common words in other languages
    const lowerText = text.toLowerCase();
    if (/\b(hola|gracias|por favor|buenos días)\b/.test(lowerText)) return 'es-ES';
    if (/\b(bonjour|merci|s'il vous plaît)\b/.test(lowerText)) return 'fr-FR';
    if (/\b(hallo|danke|bitte)\b/.test(lowerText)) return 'de-DE';
    if (/\b(ciao|grazie|prego)\b/.test(lowerText)) return 'it-IT';
    if (/\b(olá|obrigado|por favor)\b/.test(lowerText)) return 'pt-BR';
    
    return 'en-US'; // Default to English
  };

  // Get appropriate voice for language
  const getVoiceForLanguage = (langCode) => {
    const voices = synthRef.current.getVoices();
    
    console.log('🔍 Looking for voice with language:', langCode);
    console.log('📋 Available voices:', voices.length);
    
    if (voices.length === 0) {
      console.warn('⚠️ No voices loaded yet');
      return null;
    }
    
    // Try exact match first
    let voice = voices.find(v => v.lang === langCode);
    
    if (voice) {
      console.log('✅ Found exact match:', voice.name, voice.lang);
      return voice;
    }
    
    // Try language code without region (e.g., 'hi' from 'hi-IN')
    const shortLang = langCode.split('-')[0];
    voice = voices.find(v => v.lang.startsWith(shortLang));
    
    if (voice) {
      console.log('✅ Found language match:', voice.name, voice.lang);
      return voice;
    }
    
    // For Hindi specifically, try common Hindi voice names
    if (shortLang === 'hi') {
      voice = voices.find(v => 
        v.name.toLowerCase().includes('hindi') || 
        v.lang.includes('hi')
      );
      if (voice) {
        console.log('✅ Found Hindi voice by name:', voice.name, voice.lang);
        return voice;
      }
    }
    
    // Fallback to English
    voice = voices.find(v => v.lang.startsWith('en'));
    
    if (voice) {
      console.log('⚠️ Using English fallback:', voice.name, voice.lang);
    } else {
      console.log('⚠️ Using default voice');
      voice = voices[0];
    }
    
    return voice;
  };

  // Start listening
  const startListening = () => {
    if (!isSupported) {
      toast.error('Voice recognition not supported. Please use Chrome, Edge, or Safari.');
      return;
    }

    setCurrentTranscript('');
    setIsListening(true);
    
    try {
      recognitionRef.current.start();
      // REMOVED: No more annoying "I'm listening. Go ahead!" announcement
    } catch (error) {
      console.error('Failed to start listening:', error);
      setIsListening(false);
      toast.error('Failed to start listening. Please try again.');
    }
  };

  // Stop listening
  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
    clearTimeout(silenceTimerRef.current);
    
    // Send current transcript if exists
    if (currentTranscript.trim()) {
      handleSendMessage(currentTranscript);
    }
  };

  // Text-to-speech with multi-language support
  const speak = (text, languageCode = null) => {
    if (!synthRef.current || !('speechSynthesis' in window)) {
      console.warn('Speech synthesis not available');
      return;
    }

    // Stop any ongoing speech
    synthRef.current.cancel();

    // Detect language if not provided
    const detectedLang = languageCode || detectLanguage(text);
    
    console.log('🗣️ Speaking text:', text.substring(0, 50));
    console.log('🌍 Detected language:', detectedLang);
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Get appropriate voice for the language
    const voice = getVoiceForLanguage(detectedLang);
    
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
      console.log('🎤 Using voice:', voice.name, '(', voice.lang, ')');
    } else {
      utterance.lang = detectedLang;
      console.log('🎤 No specific voice found, using lang:', detectedLang);
    }
    
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    utterance.onstart = () => {
      console.log('▶️ Started speaking in', utterance.lang);
    };
    
    utterance.onend = () => {
      console.log('⏹️ Finished speaking');
    };
    
    utterance.onerror = (event) => {
      console.error('❌ Speech error:', event.error);
    };
    
    // Small delay to ensure synthesis is ready
    setTimeout(() => {
      synthRef.current.speak(utterance);
    }, 100);
  };

  // Handle sending message (voice or text)
  const handleSendMessage = async (message) => {
    const userMessage = message || textInput;
    
    if (!userMessage.trim()) return;

    // Stop listening if active
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    }

    // Add user message to chat
    const userChatEntry = {
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    };
    setChatHistory(prev => [...prev, userChatEntry]);
    
    // Clear inputs
    setTextInput('');
    setCurrentTranscript('');
    setIsProcessing(true);

    try {
      // Detect language from user input
      const inputLanguage = detectLanguage(userMessage);
      const langCode = inputLanguage.split('-')[0]; // e.g., 'hi' from 'hi-IN'
      
      console.log('📤 Sending message in language:', langCode);

      // Call AI API
      const response = await axios.post(
        `${API_URL}/api/process-voice-command`,
        {
          user_input: userMessage,
          language: langCode // Send detected language
        },
        {
          timeout: 30000,
          headers: { 'Content-Type': 'application/json' }
        }
      );

      const { commands, response_text, detected_language } = response.data;

      console.log('📥 Response language from API:', detected_language);
      console.log('📝 Response text:', response_text.substring(0, 100));

      // Add AI response to chat
      const aiChatEntry = {
        role: 'assistant',
        content: response_text,
        timestamp: new Date()
      };
      setChatHistory(prev => [...prev, aiChatEntry]);

      // Determine language for TTS
      // Priority: detected_language from API > detected from response text > detected from input
      let speakLanguage = null;
      
      if (detected_language) {
        // Map short codes to full codes
        const langMap = {
          'en': 'en-US',
          'hi': 'hi-IN',
          'es': 'es-ES',
          'fr': 'fr-FR',
          'de': 'de-DE',
          'zh': 'zh-CN',
          'ja': 'ja-JP',
          'ar': 'ar-SA',
          'pt': 'pt-BR',
          'it': 'it-IT',
          'ru': 'ru-RU',
          'ko': 'ko-KR'
        };
        speakLanguage = langMap[detected_language] || detected_language;
      } else {
        // Detect from response text
        speakLanguage = detectLanguage(response_text);
      }
      
      console.log('🎯 Final TTS language:', speakLanguage);

      // Speak response in correct language
      speak(response_text, speakLanguage);

      // Execute form commands if any
      if (commands && commands.length > 0 && onVoiceCommand) {
        commands.forEach(command => {
          onVoiceCommand(command);
        });
      }

    } catch (error) {
      console.error('AI processing error:', error);
      
      const errorMessage = error.response?.data?.detail || 'Sorry, I had trouble processing that. Please try again.';
      
      const errorChatEntry = {
        role: 'assistant',
        content: `❌ ${errorMessage}`,
        timestamp: new Date()
      };
      setChatHistory(prev => [...prev, errorChatEntry]);
      
      toast.error('Failed to process message. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle text input submit
  const handleTextSubmit = (e) => {
    e.preventDefault();
    if (textInput.trim()) {
      handleSendMessage(textInput);
    }
  };

  // Toggle assistant panel
  const toggleOpen = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      // Auto-focus text input when opening
      setTimeout(() => {
        document.getElementById('voice-text-input')?.focus();
      }, 100);
    }
  };

  if (!isSupported) {
    return null; // Don't show if not supported
  }

  return (
    <>
      {/* Floating Voice Button */}
      <button
        onClick={toggleOpen}
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110 flex items-center justify-center ${
          isListening 
            ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
            : isProcessing
            ? 'bg-yellow-500 hover:bg-yellow-600'
            : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
        }`}
        title="AI Voice Assistant"
      >
        <div className="relative">
          <FaRobot className="text-white text-2xl" />
          {isProcessing && (
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-400 rounded-full animate-ping"></div>
          )}
          {chatHistory.length > 1 && !isOpen && (
            <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
              {chatHistory.length - 1}
            </div>
          )}
        </div>
      </button>

      {/* Voice Assistant Chat Panel */}
      {isOpen && (
        <div className="fixed bottom-28 right-6 z-50 w-96 max-w-[calc(100vw-3rem)] animate-slide-up">
          <div className={`rounded-2xl shadow-2xl overflow-hidden ${
            darkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'
          }`}>
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <FaRobot className="text-white text-xl animate-bounce" />
                  <div>
                    <h3 className="text-white font-bold">AI Travel Assistant</h3>
                    <p className="text-xs text-blue-100">
                      {isListening ? '🎤 Listening...' : isProcessing ? '🤔 Thinking...' : '💬 Ask me anything!'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={toggleOpen}
                  className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
                >
                  <FaTimes />
                </button>
              </div>
            </div>

            {/* Chat Messages */}
            <div className={`h-96 overflow-y-auto p-4 space-y-3 ${
              darkMode ? 'bg-gray-900' : 'bg-gray-50'
            }`}>
              {chatHistory.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.role === 'user'
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-br-none'
                        : darkMode
                        ? 'bg-gray-800 text-gray-100 rounded-bl-none'
                        : 'bg-white text-gray-900 rounded-bl-none shadow-md'
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    <p className={`text-xs mt-1 ${
                      message.role === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              
              {/* Current listening transcript */}
              {isListening && currentTranscript && (
                <div className="flex justify-end">
                  <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-blue-500/30 text-blue-700 dark:text-blue-300 rounded-br-none border-2 border-blue-400 border-dashed">
                    <p className="text-sm italic">{currentTranscript}</p>
                    <p className="text-xs mt-1">Listening...</p>
                  </div>
                </div>
              )}
              
              {isProcessing && (
                <div className="flex justify-start">
                  <div className={`rounded-2xl px-4 py-3 ${
                    darkMode ? 'bg-gray-800' : 'bg-white shadow-md'
                  }`}>
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={chatEndRef} />
            </div>

            {/* Input Area */}
            <div className={`p-4 border-t ${
              darkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
            }`}>
              <form onSubmit={handleTextSubmit} className="flex space-x-2">
                <input
                  id="voice-text-input"
                  type="text"
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Type your message or use voice..."
                  disabled={isListening || isProcessing}
                  className={`flex-1 px-4 py-2 rounded-xl border-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    darkMode
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                      : 'bg-gray-50 border-gray-200 text-gray-900'
                  } ${(isListening || isProcessing) ? 'opacity-50 cursor-not-allowed' : ''}`}
                />
                
                <button
                  type="button"
                  onClick={isListening ? stopListening : startListening}
                  disabled={isProcessing}
                  className={`p-3 rounded-xl transition-all ${
                    isListening
                      ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                      : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
                  } text-white disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {isListening ? <FaMicrophoneSlash /> : <FaMicrophone />}
                </button>
                
                <button
                  type="submit"
                  disabled={!textInput.trim() || isProcessing}
                  className="p-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  <FaPaperPlane />
                </button>
              </form>
              
              <div className="mt-2 text-xs text-center text-gray-500">
                {isListening ? (
                  <span className="text-red-500 font-semibold">🎤 Listening... (Click mic to send)</span>
                ) : voicesLoaded ? (
                  <span>Click 🎤 to speak or type your message</span>
                ) : (
                  <span className="text-yellow-600">⏳ Loading voices...</span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Custom CSS for slide-up animation */}
      <style jsx>{`
        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </>
  );
}

export default VoiceAssistant;